<?php
//session start


error_reporting(0);
$servername="localhost";
$host="localhost";
$user="root";
$password="";
$db="greenharvest";

$conn= mysqli_connect($host, $user, $password, $db);
if($conn->connect_error)
	echo "failed to connect db" .$conn->connect_error;
else
{
	//echo "connection" ;
}

?>