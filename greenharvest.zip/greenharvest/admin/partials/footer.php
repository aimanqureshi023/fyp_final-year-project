
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Green Harvest Project</title>
	<link rel="stylesheet" type="text/css" href="..//css/admin.css">
</head>
<body>


<div class="footer">
  	<div class="wrapper">
  		<p class="text-center">2024 All rights reserved , Farmer website .Developed by -<a href="#">Adeel </a></p>
	</div>
  	
  </div>
  <!--footer section here-->
</body>
</html>