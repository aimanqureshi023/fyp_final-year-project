<?php include ('../config/constants.php') ;?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Green Harvest Project</title>
	<link rel="stylesheet" type="text/css" href="..//css/admin.css">
</head>
<body>
  <!--menu section here-->
<div class="menu">
	<div class="wrapper text-center"><ul>
			<li><a href="index.php"> Home</a></li>
			<li><a href="manage-admin.php"> Admin</a></li>
			<li><a href="manage-categories.php"> Category</a></li>
			<li><a href="manage-product.php"> Product</a></li>
			<li><a href="manage-order.php"> Order</a></li>
		</ul>
	
	</div>
</div>
</body>
</html>