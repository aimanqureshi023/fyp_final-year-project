<?php include('partials/menu.php');?>
<?php 
//include ('../config/connection.php');

 if (isset($_POST['submit'])) {
   // $id = $_POST['id'];
 	$full_name = $_POST['full_name'];
 	$username = $_POST['username'];
 	$password = $_POST['password'];
 	//$submit = $_POST['submit'];

 	$insertquery = "INSERT INTO admin (full_name , username , password) VALUES ('$full_name' , '$username','$password')";
    $res = mysqli_query($conn,$insertquery);
    if ($res==TRUE) {
    	$_SESSION['add'] ="add admin successfully";
    	//redirect page to manage-admin
    	header("location:" .SITEURL.'admin/manage-admin.php');
    ?>
    <script>
    	alert ("Data Inserted");
    </script>
    <?php
 }
    else
    {
    	$_SESSION['add'] ="Failed to add admin";
    	//redirect page to add-admin
    	header("location:" .SITEURL.'admin/add-admin.php');
    	?>
    	<script>
    	alert ("Data not Inserted");
    </script>
    <?php
    }
 }

?>
<!--main content section here-->
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>


<div class="main">
	<div class="wrapper">
		
	<h1>Add Admin</h1>
	<br><br>
	<?php
	if(isset($_SESSION['add']))
{
	echo $_SESSION['add'];
	unset($_SESSION['add']);
}
	?>

	<form action="" method="POST">
		<table class="trew">
			<tr>
			<td>Fullname</td>
			<td><input type="text" name="full_name" placeholder="enter your name"></td>
			
		</tr>
		<tr>
			<td>Username</td>
			<td><input type="text" name="username" placeholder="enter username"></td>
			
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="password" name="password" placeholder="enter password"></td>
			
		</tr>

		<tr>
		<td colspan="2"></td>
		<td><br><br><input type="submit" name="submit" value="Add Admin" class="btn-secondary"></td>
		</tr>

		</table>
	</form>

		</div>
	
</div>


</body>
</html>
<?php
include('partials/footer.php'); 
?>