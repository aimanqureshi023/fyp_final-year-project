<?php include('partials/menu.php');?>
  <!--main content section here-->
<div class="main">
	<div class="wrapper">
		
	<h1>Dashboard</h1>
	<div class="col-4 text-center">
		<h1>4</h1>
		<br>
Categories
	</div>
	<div class="col-4 text-center">
		<h1>4</h1>
		<br>
Categories
	</div>
	<div class="col-4 text-center">
		<h1>4</h1>
		<br>
Categories
	</div>
	<div class="col-4 text-center">
		<h1>4</h1>
		<br>
Categories
	</div>
	<div class="clearfix"></div>
	</div>
	
</div>
  <!--main content  section here-->
  <?php include('partials/footer.php');?>