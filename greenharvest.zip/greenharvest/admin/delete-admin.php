<?php
include ('../config/constants.php');
 $id= $_GET['id'];
 $sql = "DELETE  FROM admin WHERE id=$id";
 $res = mysqli_query($conn, $sql);
 if($res==TRUE)
 {
   echo "delete admin";
   $_SESSION['delete'] ="delete admin successfully";
   header('loccation:' .SITEURL.'admin/manage-admin.php');
 }
 else
 {
    echo "failed to delete";
   $_SESSION['delete'] =" admin not deleted";
   header('location:' .SITEURL.'admin/manage-admin.php');
 }
?>