<?php include('partials/menu.php');?>
<<!--main content section here-->
<div class="main">
	<div class="wrapper">
		
	<h1>Manage Categories</h1>

		</div>
	
</div>

<?php include('partials/footer.php');?>